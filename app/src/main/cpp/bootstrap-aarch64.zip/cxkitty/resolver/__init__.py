from .question import QuestionResolver
from .media import MediaPlayResolver
from .document import DocumetResolver
