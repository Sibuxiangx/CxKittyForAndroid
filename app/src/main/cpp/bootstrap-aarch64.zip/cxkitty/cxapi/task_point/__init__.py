from .document import PointDocumentDto
from .video import PointVideoDto
from .work import PointWorkDto
